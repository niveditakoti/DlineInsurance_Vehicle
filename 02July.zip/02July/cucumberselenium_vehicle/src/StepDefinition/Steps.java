package StepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Steps {
	
	WebDriver driver;
	
	
	
	@Given("^The Vehicle registration number \"(.*?)\"$")
	public void the_Vehicle_registration_number(String Regno) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 System.out.println("=====================================================");
	    System.out.println("Vehicle Registration number :" + Regno);
	    System.out.println("=====================================================");
	   
	}

	@When("^I launch the covercheck insurance portal application$")
	public void i_launch_the_covercheck_insurance_portal_application() throws Throwable {
	   	System.setProperty("webdriver.chrome.driver", "C:\\Nivedita\\chromedriver.exe");					
	       driver= new ChromeDriver();					
	       driver.manage().window().maximize();			
	       driver.get("https://covercheck.vwfsinsuranceportal.co.uk/");	
	}

	@When("^I enter the Vehicle registration number \"(.*?)\"$")
	public void i_enter_the_Vehicle_registration_number(String Regno) throws Throwable {
	 
	    driver.findElement(By.name("vehicleReg")).sendKeys(Regno);							
	  
	}

	@When("^I click on Find Vehicle button$")
	public void i_click_on_Find_Vehicle_button() throws Throwable {
		
		 driver.findElement(By.name("btnfind")).click();	
		
	}

	@Then("^I validate the Vehicle Cover Start and End date$")
	public void i_validate_the_Vehicle_Cover_Start_and_End_date() throws Throwable {
			Thread.sleep(5000);
			System.out.println("Cover Start date  : " + driver.findElement(By.xpath("(//div[@class='result'])[1]/../div[2]/span")).getText());
			System.out.println("Cover End date  : " + driver.findElement(By.xpath("(//div[@class='result'])[1]/../div[3]/span")).getText());
	}

}
